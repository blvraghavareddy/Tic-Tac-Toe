package com.mycompany.tic_tac_toe;


import java.awt.Color;
import javax.swing.JOptionPane;


public class game extends javax.swing.JFrame {

    /**
     * Creates new form game
     */
    String x_Name,o_Name, winner,check;
    private int round = 0, flag;
    private int xF, oF;
    
    boolean checker = false;
    
    
    public game(String x_name,String o_name) {
        
        this.x_Name = x_name;
        this.o_Name = o_name;
        
        
        initComponents();
        labelchange();
        
    }
    
   
    private void Score(){
        
        xc.setText(String.valueOf(xF));
        oc.setText(String.valueOf(oF));
        rou();
        
    }
    
    private void labelchange(){
        
        
        
        xname.setText(x_Name);
        oname.setText(o_Name);
        
        if(checker == false){
            dispalylabel.setText(x_Name+" turn ");
        }
        else{
            dispalylabel.setText(o_Name+" turn ");
        }
    }
    
    private void change(){
        
        
        b1.setText("");
        b2.setText("");
        b3.setText("");
        b4.setText("");
        b5.setText("");
        b6.setText("");
        b7.setText("");
        b8.setText("");
        b9.setText("");
        
        b1.setBackground(new java.awt.Color(204, 255, 255));
        b2.setBackground(new java.awt.Color(204, 255, 255));
        b3.setBackground(new java.awt.Color(204, 255, 255));
        b4.setBackground(new java.awt.Color(204, 255, 255));
        b5.setBackground(new java.awt.Color(204, 255, 255));
        b6.setBackground(new java.awt.Color(204, 255, 255));
        b7.setBackground(new java.awt.Color(204, 255, 255));
        b8.setBackground(new java.awt.Color(204, 255, 255));
        b9.setBackground(new java.awt.Color(204, 255, 255));
}

   
    private void winning(){
        
      String b_1 = b1.getText();
      String b_2 = b2.getText();
      String b_3 = b3.getText();
      String b_4 = b4.getText();
      String b_5 = b5.getText();
      String b_6 = b6.getText();
      String b_7 = b7.getText();
      String b_8 = b8.getText();
      String b_9 = b9.getText();
      
      if(b_1 == ("X") && b_2 == ("X") && b_3 == ("X")){
         
          b1.setBackground(Color.ORANGE);
          b2.setBackground(Color.ORANGE);
          b3.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      else if(b_4 == ("X") && b_5 == ("X") && b_6 == ("X")){
         
          b4.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b6.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_7 == ("X") && b_8 == ("X") && b_9== ("X")){
         
          b7.setBackground(Color.ORANGE);
          b8.setBackground(Color.ORANGE);
          b9.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_1 == ("X") && b_4 == ("X") && b_7== ("X")){
         
          b1.setBackground(Color.ORANGE);
          b4.setBackground(Color.ORANGE);
          b7.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_2 == ("X") && b_5 == ("X") && b_8== ("X")){
         
          b2.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b8.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_3 == ("X") && b_6 == ("X") && b_9== ("X")){
         
          b3.setBackground(Color.ORANGE);
          b6.setBackground(Color.ORANGE);
          b9.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_1 == ("O") && b_4 == ("O") && b_7== ("O")){
         
          b1.setBackground(Color.ORANGE);
          b4.setBackground(Color.ORANGE);
          b7.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_2 == ("O") && b_5 == ("O") && b_8== ("O")){
         
          b2.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b8.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_3 == ("O") && b_6 == ("O") && b_9== ("O")){
         
          b3.setBackground(Color.ORANGE);
          b6.setBackground(Color.ORANGE);
          b9.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_1 == ("X") && b_5 == ("X") && b_9 == ("X")){
         
          b1.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b9.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      else if(b_3 == ("X") && b_5 == ("X") && b_7 == ("X")){
         
          b3.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b7.setBackground(Color.ORANGE);
          xF++;
          winner = x_Name;
          round++;
          
          Score();
          
      }
      
      
      
      
      
      
      else if(b_1 == ("O") && b_2 == ("O") && b_3 == ("O")){
         
          b1.setBackground(Color.ORANGE);
          b2.setBackground(Color.ORANGE);
          b3.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      else if(b_4 == ("O") && b_5 == ("O") && b_6 == ("O")){
         
          b4.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b6.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      
      else if(b_7 == ("O") && b_8 == ("O") && b_9== ("O")){
         
          b7.setBackground(Color.ORANGE);
          b8.setBackground(Color.ORANGE);
          b9.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      else if(b_1 == ("O") && b_5 == ("O") && b_9 == ("O")){
         
          b1.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b9.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      else if(b_3 == ("O") && b_5 == ("O") && b_7 == ("O")){
         
          b3.setBackground(Color.ORANGE);
          b5.setBackground(Color.ORANGE);
          b7.setBackground(Color.ORANGE);
          oF++;
          winner = o_Name;
          round++;
          
          Score();
          
      }
      
      
      
      
    }
    
    private void rou(){
        
            
      
     
        if(xF==3){
            String s4 = "Game over\nWinner is "+x_Name;
            dispalylabel.setText("Game Over");
            JOptionPane.showMessageDialog(this, s4, "TIC - TAC - TOE",JOptionPane.INFORMATION_MESSAGE );
                    
            dispose();
        }
        else if(oF==3){
            String s5 = "Game over\nWinner is "+o_Name;
            dispalylabel.setText("Game Over");
            JOptionPane.showMessageDialog(this, s5, "TIC - TAC - TOE",JOptionPane.INFORMATION_MESSAGE );
            
            dispose();
        }
        
        else if(round == 5){
            if(xF > oF){
                String s8 = "Game over\nWinner is "+x_Name;
                dispalylabel.setText("Game Over");
                JOptionPane.showMessageDialog(this, s8, "TIC - TAC - TOE",JOptionPane.INFORMATION_MESSAGE );
                dispose();
            }
            else{
                String s9 = "Game over\nWinner is "+o_Name;
                dispalylabel.setText("Game Over");
                JOptionPane.showMessageDialog(this, s9, "TIC - TAC - TOE",JOptionPane.INFORMATION_MESSAGE );
                dispose();
            }
        }
        else{
            check = "Round : "+String.valueOf(round)+" Completed...\nWinner is "+winner;
            String s10 = "Round : "+String.valueOf(round)+" Completed...";
            dispalylabel.setText(s10);
            JOptionPane.showMessageDialog(this, check, "TIC - TAC - TOE",JOptionPane.INFORMATION_MESSAGE );
            change();
        
            
        }
        
            if(flag == 1){
            checker = false;
            flag = 0;
            }
            else{
            checker = true;
            flag = 1;
            }
            labelchange();
        
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        dispalylabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        b2 = new javax.swing.JButton();
        b1 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        xname = new javax.swing.JLabel();
        xc = new javax.swing.JLabel();
        oname = new javax.swing.JLabel();
        oc = new javax.swing.JLabel();
        exitbutton = new javax.swing.JButton();
        resetbutton = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TIC - TAC - TOE");

        jPanel4.setBackground(new java.awt.Color(0, 204, 204));

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        dispalylabel.setFont(new java.awt.Font("Consolas", 0, 48)); // NOI18N
        dispalylabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dispalylabel.setText("playername");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dispalylabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dispalylabel, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        b2.setBackground(new java.awt.Color(204, 255, 255));
        b2.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b2.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b2.setFocusPainted(false);
        b2.setFocusable(false);
        b2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b1.setBackground(new java.awt.Color(204, 255, 255));
        b1.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b1.setFocusPainted(false);
        b1.setFocusable(false);
        b1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b3.setBackground(new java.awt.Color(204, 255, 255));
        b3.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b3.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b3.setFocusPainted(false);
        b3.setFocusable(false);
        b3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        b4.setBackground(new java.awt.Color(204, 255, 255));
        b4.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b4.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b4.setFocusPainted(false);
        b4.setFocusable(false);
        b4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        b5.setBackground(new java.awt.Color(204, 255, 255));
        b5.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b5.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b5.setFocusPainted(false);
        b5.setFocusable(false);
        b5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b6.setBackground(new java.awt.Color(204, 255, 255));
        b6.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b6.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b6.setFocusPainted(false);
        b6.setFocusable(false);
        b6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b7.setBackground(new java.awt.Color(204, 255, 255));
        b7.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b7.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b7.setFocusPainted(false);
        b7.setFocusable(false);
        b7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        b8.setBackground(new java.awt.Color(204, 255, 255));
        b8.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b8.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b8.setFocusPainted(false);
        b8.setFocusable(false);
        b8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b9.setBackground(new java.awt.Color(204, 255, 255));
        b9.setFont(new java.awt.Font("Arial", 0, 72)); // NOI18N
        b9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b9.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        b9.setFocusPainted(false);
        b9.setFocusable(false);
        b9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(9, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel5.setBackground(new java.awt.Color(0, 204, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Score");

        xname.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        xname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xname.setText("playername");

        xc.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        xc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        xc.setText("0");
        xc.setOpaque(true);

        oname.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        oname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        oname.setText("playername");

        oc.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        oc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        oc.setText("0");
        oc.setOpaque(true);

        exitbutton.setBackground(new java.awt.Color(204, 255, 255));
        exitbutton.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        exitbutton.setText("Exit");
        exitbutton.setFocusable(false);
        exitbutton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        exitbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbuttonActionPerformed(evt);
            }
        });

        resetbutton.setBackground(new java.awt.Color(204, 255, 255));
        resetbutton.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        resetbutton.setText("Reset");
        resetbutton.setFocusable(false);
        resetbutton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        resetbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetbuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(xname, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                            .addComponent(oname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(xc, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(oc, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(83, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(exitbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(resetbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(81, 81, 81))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(xname, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(xc, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oname, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oc, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(resetbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(exitbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
        
    
    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        // TODO add your handling code here:
        
        if(checker){
            if(b2.getText()==""){
                b2.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b2.getText()==""){
                b2.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b2ActionPerformed

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        // TODO add your handling code here:
       if(checker){
            if(b1.getText()==""){
                b1.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b1.getText()==""){
                b1.setText("X");
                checker=true;
                labelchange();
                winning();}
        }

       
        
    }//GEN-LAST:event_b1ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
       if(checker){
            if(b3.getText()==""){
                b3.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b3.getText()==""){
                b3.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b3ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        // TODO add your handling code here:
        if(checker){
            if(b4.getText()==""){
                b4.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b4.getText()==""){
                b4.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b4ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        // TODO add your handling code here:
        if(checker){
            if(b5.getText()==""){
                b5.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b5.getText()==""){
                b5.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b5ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        // TODO add your handling code here:
        if(checker){
            if(b6.getText()==""){
                b6.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b6.getText()==""){
                b6.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b6ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        // TODO add your handling code here:
       if(checker){
            if(b7.getText()==""){
                b7.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b7.getText()==""){
                b7.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b7ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        // TODO add your handling code here:
       if(checker){
            if(b8.getText()==""){
                b8.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b8.getText()==""){
                b8.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b8ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        // TODO add your handling code here:
       if(checker){
            if(b9.getText()==""){
                b9.setText("O");
                checker=false;
                labelchange();
                winning();
            }
        }
        else{
            if(b9.getText()==""){
                b9.setText("X");
                checker=true;
                labelchange();
                winning();}
        }
    }//GEN-LAST:event_b9ActionPerformed

    private void resetbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetbuttonActionPerformed
        // TODO add your handling code here:
        checker = false;
        change();
        labelchange();
        
        
        
        
    }//GEN-LAST:event_resetbuttonActionPerformed

    private void exitbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbuttonActionPerformed
        // TODO add your handling code here:
        if(JOptionPane.showConfirmDialog(jPanel4,"Confrim to exit","TIC - TAC - TOE",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION){
             dispose();
        }
       
    }//GEN-LAST:event_exitbuttonActionPerformed

    
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new game("","").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    private javax.swing.JLabel dispalylabel;
    private javax.swing.JButton exitbutton;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel oc;
    private javax.swing.JLabel oname;
    private javax.swing.JButton resetbutton;
    private javax.swing.JLabel xc;
    private javax.swing.JLabel xname;
    // End of variables declaration//GEN-END:variables
}