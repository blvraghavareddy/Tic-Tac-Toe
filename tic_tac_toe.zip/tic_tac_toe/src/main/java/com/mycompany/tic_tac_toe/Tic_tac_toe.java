package com.mycompany.tic_tac_toe;

/**
 *
 * @author rakes
 */
public class Tic_tac_toe {

    public static void main(String[] args) {
        
        new welcome().setVisible(true);
    }
}